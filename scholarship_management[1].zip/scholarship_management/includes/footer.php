<footer class="bg-dark text-white text-center py-3 mt-5">
    <div class="container">
        <p>&copy; 2024 Scholarship Portal. All rights reserved.</p>
        <p>M.C.E Society's Dr. P.A. Inamdar University</p>
    </div>
</footer>